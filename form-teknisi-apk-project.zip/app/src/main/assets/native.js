// Jembatan ke aplikasi Android: kirim teks + foto langsung ke WhatsApp
(function () {
  if (!window.AndroidBridge) return;
  function b64(file) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { var s = r.result; res(s.slice(s.indexOf(",") + 1)); };
      r.onerror = function () { rej(new Error("baca file gagal")); };
      r.readAsDataURL(file);
    });
  }
  function share(d) {
    var files = (d && d.files) || [];
    window.AndroidBridge.begin((d && d.text) || "");
    var p = Promise.resolve();
    files.forEach(function (f, i) {
      p = p.then(function () { return b64(f); }).then(function (s) {
        window.AndroidBridge.addFile(f.name || ("foto" + (i + 1) + ".jpg"), f.type || "image/jpeg", s);
      });
    });
    return p.then(function () { window.AndroidBridge.finish(); });
  }
  try { Object.defineProperty(navigator, "share", { value: share, configurable: true }); } catch (e) { navigator.share = share; }
  try { Object.defineProperty(navigator, "canShare", { value: function () { return true; }, configurable: true }); } catch (e) { navigator.canShare = function () { return true; }; }
})();
